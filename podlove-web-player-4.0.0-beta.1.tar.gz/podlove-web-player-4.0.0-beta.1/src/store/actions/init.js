const init = config => ({
  type: 'INIT',
  payload: config
})

export {
  init
}
