const setDownloadFile = url => ({
  type: 'SET_DOWNLOAD_FILE',
  payload: url
})

export {
  setDownloadFile
}
