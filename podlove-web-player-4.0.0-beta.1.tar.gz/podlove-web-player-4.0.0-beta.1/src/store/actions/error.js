const errorLoad = () => ({
  type: 'ERROR_LOAD'
})

const errorMissingAudioFiles = () => ({
  type: 'ERROR_MISSING_AUDIO_FILES'
})

export {
  errorLoad,
  errorMissingAudioFiles
}
