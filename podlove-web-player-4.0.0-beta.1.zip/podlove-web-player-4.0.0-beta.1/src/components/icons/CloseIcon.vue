<template>
  <svg width="16" height="16" viewBox="329 30 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
      <rect stroke="none" :fill="color" fill-rule="evenodd" transform="translate(337.000000, 38.000000) rotate(-315.000000) translate(-337.000000, -38.000000) " x="336" y="28" width="2" height="20"></rect>
      <rect stroke="none" :fill="color" fill-rule="evenodd" transform="translate(337.000000, 38.000000) rotate(-45.000000) translate(-337.000000, -38.000000) " x="336" y="28" width="2" height="20"></rect>
  </svg>
</template>

<script>
  export default {
    props: ['color']
  }
</script>
