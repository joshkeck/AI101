import 'babel-polyfill'
import app from '../app'

app(window.PODLOVE)
