const setTheme = theme => ({
  type: 'SET_THEME',
  payload: theme
})

export {
  setTheme
}
