const setLanguage = lang => ({
  type: 'SET_LANGUAGE',
  payload: lang
})

export {
  setLanguage
}
